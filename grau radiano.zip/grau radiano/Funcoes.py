#Versão 4.2

#def das operacoes
#qp = quadrante positivo
# de graus para radiano / gr = graus radiano / resprad = resposta em radiano

ol=0
def graurad(respgr):
    gr= respgr
    if (gr <= 180 ) :
        if(gr == 180):
            respradt = 'pi'
            return respradt
        if(gr == 0):
            respradt='2pi'
            return respradt
        else :
            # OK
            if(180 % gr == 0):
                g = 180 / gr
                respradt= f' pi/ {g}'
                ol=(180/g)

                return respradt

            #    TRALHANDO !!!

            else:
                #180  r
                #gr   X
                if (gr % 10 == 0):
                    gr2 = gr =gr /10
                    #gr == grau fixo = 180
                    gf =18
                    ol=0
                    while(ol != gr2):
                        if(gr%9 == 0 and gf%9 ==0 ):
                            gr /= 9
                            gf/=9
                            ol = (gr*180)/gf
                        if (gr % 5 == 0 and gf % 5 == 0):
                            gr /= 5
                            gf /= 5
                            ol = (gr * 180) / gf
                        if (gr % 3 == 0 and gf % 3 == 0):
                            gr /= 3
                            gf /= 3
                            ol = (gr * 180) / gf
                        if (gr % 2 == 0 and gf % 2 == 0):
                            gr /= 2
                            gf /= 2
                            ol = (gr * 180) / gf
                        else:
                            ol = (gr * 180) / gf

                            break

                    respgr = f' {gr} pi / {gf} '
                    return respgr
                else:
                    gr2 = gr
                    # gr == grau fixo = 180
                    gf = 180
                    ol=0
                    while (ol != gr2):
                        if (gr % 9 == 0 and gf % 9 == 0):
                            gr /= 9
                            gf /= 9
                            ol = (gr * 180) / gf
                        if (gr % 5 == 0 and gf % 5 == 0):
                            gr /= 5
                            gf /= 5
                            ol = (gr * 180) / gf
                        if (gr % 3 == 0 and gf % 3 == 0):
                            gr /= 3
                            gf /= 3
                            ol = (gr * 180) / gf
                        if (gr % 2 == 0 and gf % 2 == 0):
                            gr /= 2
                            gf /= 2
                            ol = (gr * 180) / gf
                        else:
                            ol = (gr * 180) / gf
                            break

                    respgr = f' {gr} pi / {gf} '
                    return respgr

    # > 180

    else:
        if(gr == 360 or gr == 0):
                g = 180 / gr
                respradt= f'2pi/{g}'
                ol=(180/g)
                return respradt
        else:
            if (gr % 10 == 0):
                gr2 = gr = gr / 10
                # gr == grau fixo = 180
                gf = 18
                ol=0
                while (ol != gr2):
                    if (gr % 9 == 0 and gf % 9 == 0):
                        gr /= 9
                        gf /= 9
                        ol = (gr * 180) / gf
                    if (gr % 5 == 0 and gf % 5 == 0):
                        gr /= 5
                        gf /= 5
                        ol = (gr * 180) / gf
                    if (gr % 3 == 0 and gf % 3 == 0):
                        gr /= 3
                        gf /= 3
                        ol = (gr * 180) /gf
                    if (gr % 2 == 0 and gf % 2 == 0):
                        gr /= 2
                        gf /= 2
                        ol = (gr * 180) / gf
                    else:
                        ol = (gr * 180) / gf
                        break

                respgr = f'{gr} pi / {gf} '
                return respgr

            else:
                gr2 = gr
                # gr == grau fixo = 180
                gf = 180
                ol=0
                while (ol != gr2):
                    if (gr % 9 == 0 and gf % 9 == 0):
                        gr /= 9
                        gf /= 9
                        ol = (gr * 180) / gf
                    if (gr % 5 == 0 and gf % 5 == 0):
                        gr /= 5
                        gf /= 5
                        ol = (gr * 180) / gf
                    if (gr % 3 == 0 and gf % 3 == 0):
                        gr /= 3
                        gf /= 3
                        ol = (gr * 180) / gf
                    if (gr % 2 == 0 and gf % 2 == 0):
                        gr /= 2
                        gf /= 2
                        ol = (gr * 180) / gf
                    else:
                        ol = (gr * 180) / gf
                        break

                respgr = f'{gr} pi / {gf} '
                return respgr


def qp(qua):
    if (qua > 0) and (qua < 90):
        print(f'{qua} pertence ao 1º quadrante')
    if (qua == 90):
        print(f'{qua}º intermediario entre o 1º eo 2º quadrante')
    if (qua > 90) and (qua < 180):
        print(f'{qua} pertence ao 2º quadrante')
    if (qua == 180):
        print(f'{qua} º intermediario entre o 2º eo 3º quadrante')
    if (qua > 180) and (qua < 270):
        print(f'{qua} pertence ao 3º quadrante')
    if (qua == 270):
        print(f'{qua} º intermediario entre o 3º eo 4º quadrante')
    if (qua > 270) and (qua < 360):
        print(f'{qua} pertence ao 4º quadrante')
    if (qua == 0):
        print(f'{qua} º nulo')
    if (qua == 360):
        print(f'{qua}º deu uma volta completa')

def cor ():
    from random import randint
    c = randint(1,6)
    print(f'\033[3{c}m~\033[m'*30)


#grap = grau positivo /
def radgrau(n=0,d=0):
    if (n == 0):
        grap = 180 / d
        return grap
    else :
        grap = (180 * n) / d
    return grap


#vg = voltas em graus
def voltasgraus(g):
    vgp = g // 360
    vgp *= 360
    vgp = g - vgp
    return vgp
def voltasgrausfinal(g):
    vgp2 = g // 360
    return vgp2
