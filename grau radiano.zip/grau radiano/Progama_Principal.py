# Versão final 4.1
# AUTOR : Lucas Gabriel da Silva Lima :)

import Funcoes
loop='S'
while (loop == 'S'):
    while True:
        try:
            i=int(input('\033[mDigite 1 para graus ou 2 para radiano\n'))
            while (i != 1 ) and (i != 2 ) :
                i=int(input('\033[31mResposta invalida , digite novamente !!!\033[m\n'))
        except:
            print('\033[31mErro resposta não conpativel :(\033[m')
        else:
                break
        #def das operacoes
        #voltas
        # testsegur = teste de seguraça


    # inicio do algoritmo de resposta


    resp = 0
    if (i == 1):
        # g = grau / pp = parte positiva / resp = resposta /
        Funcoes.cor()
        while True:
            try:
                g =input(f'Digite o grau\033[32m\n').strip().replace(',','.').replace(' ','')
                parse_int=float(g)
            except:
                print('\033[4;31mERRO : dado incompativel :(\033[m')
            else:
                break
        g=parse_int
        Funcoes.cor()
        if(g<0):
            if (g < 0) and (g > -360):
                t = str(g).replace("-", "")
                g = float(t)
                resp = g
                Funcoes.cor()
                print(f'\033[m{360 - resp}º na forma positiva\nEstá no sentido horario')
                Funcoes.cor()
                qua = 360 - resp
                Funcoes.qp(qua)
                Funcoes.cor()
                # colocar em radianos
                respgr=g
                Funcoes.graurad(respgr)
                respgr=qua
                print(f'A expressão é \033[34mX = {g} + K . 360º\033[m ou\nEm radiano \033[34mX = {Funcoes.graurad(respgr)} + K . 2pi\033[m')
                Funcoes.cor()
            if (g < 0 and g < -360):
                t = str(g).replace("-", "")
                g = float(t)
                Funcoes.voltasgraus(g)
                Funcoes.cor()
                print(f'\033[m{360-Funcoes.voltasgraus(g)}º na forma positiva\nEstá no sentido horario')
                Funcoes.cor()
                qua = 360-Funcoes.voltasgraus(g)
                Funcoes.qp(qua)
                Funcoes.cor()
                respgr = 360-Funcoes.voltasgraus(g)
                qua = respgr
                print(f'A expressão é \033[34mX = {360-Funcoes.voltasgraus(g)} + K . 360º\033[m ou Em radiano X = {Funcoes.graurad(respgr)} + K . 2pi\033[m')
                Funcoes.cor()
        else:
            if (g > 0) and (g < 360):
                gn=g
                Funcoes.cor()
                print(f'\033[m{g}º na forma positiva\nEstá no sentido anti-horario')
                Funcoes.cor()
                Funcoes.qp(g)
                Funcoes.cor()
                respgr=g
                print(f'A expressão é \033[34mX = {gn} + K . 360º\033[m ou Em radiano \033[34mX = {Funcoes.graurad(g)} + K . 2pi\033[m')


            if (g > 0 and g > 360):
                Funcoes.cor()
                voltasdadas=Funcoes.voltasgrausfinal(g)
                g=Funcoes.voltasgraus(g)
                print(f'\033[m{g}º na forma positiva\nEstá no sentido anti-horario\nE deu {voltasdadas} voltas')
                Funcoes.cor()
                respgr = g
                qua = g
                Funcoes.qp(qua)
                Funcoes.cor()
                print(f'A expressão é \033[34mX = {g} + K . 360º\033[m ou Em radiano \033[34mX = {Funcoes.graurad(respgr)} + K . 2pi')
                Funcoes.cor()

            # segunda parte



    if (i == 2):
        print('\033[32m               ATENÇÃO\n\033[34mSe a operação for negativa , digite o sinal no numerador !!!')
        Funcoes.cor()

        while True:
            try:
                n2 = input('\033[mDigite o numerador , se não haver ; não digite nada !\033[32m\n').strip().replace(',','.').replace(' ','')
                if (n2 == ''):
                    n2 = 0
                    n = float(n2)
                else:
                    n = float(n2)
                Funcoes.cor()
            except:
                print('\033[4;31mERRO : dado incompativel :(\033[m')
            else:
                break

        while True:
            try:
                d2 = (input('Digite o denominador ; se não houver não digite nada !\033[32m\n')).strip().replace(',','.').replace(' ','').replace('-','')
                if (d2 == ''):
                    d2 = 1
                    d = float(d2)
                else:
                    d = float(d2)
            except:
                print('\033[21mERRO : dado incompativel :(\033[m')
            else:
                break


        Funcoes.cor()
        if (n < 0):
            t = str(n).replace("-", "")
            n = float(t)
            testsegur = (180 * n) / d
            if (testsegur <= 360) :
                Funcoes.cor()
                print(f'\033[mNão deu uma volta completa  , e parou em -{testsegur}º graus ')
                Funcoes.cor()
                print(f'{360 - testsegur} na forma positiva')
                Funcoes.cor()
                print('Está no sentido horario')
                qua = Funcoes.radgrau(n,d)
                qua=360-qua
                Funcoes.qp(qua)
                Funcoes.cor()
                print(f'A expressão é \033[34mX = -{qua} pi + K . 360\033[m ou Em radiano é \033[34mX = -{Funcoes.graurad(qua)} + K * 2pi\033[m')
            else:
                Funcoes.voltasgraus(testsegur)
                Funcoes.cor()
                print(f'\033[mDeu {Funcoes.voltasgrausfinal(testsegur)} voltas , e Parou em -{Funcoes.voltasgraus(testsegur)} graus')
                Funcoes.cor()
                print(f'{360 - Funcoes.voltasgraus(testsegur)} na forma positiva')
                Funcoes.cor()
                print('Está no sentido horario')
                Funcoes.cor()
                qua = 360 - Funcoes.voltasgraus(testsegur)
                Funcoes.qp(qua)
                Funcoes.cor()
                print(f'A expressão é \033[34mX = -{qua} + K . 360\033[m ou Em radiano é \033[34mX = -{Funcoes.graurad(qua)} K * 2pi\033[m')
                Funcoes.cor()

            # forma positiva
            # Maior que zero
        else:
            testsegur = (180 * n) / d
            print(testsegur)
            if (testsegur >= 360):
                gr=Funcoes.voltasgraus(testsegur)
                voltas=Funcoes.voltasgrausfinal(testsegur)
                Funcoes.cor()
                print(f'Deu {voltas} voltas ,e parou em {gr}º graus')
                Funcoes.cor()
                print(f'{gr} na forma positiva')
                Funcoes.cor()
                print('Está no sentido anti-horario')
                Funcoes.cor()
                qua=gr
                Funcoes.qp(qua)
                print(f'A expressão é \033[34mX = {qua} + K . 360\033[m ou Em radiano é \033[34mX = {Funcoes.graurad(gr)} + K * 2pi\033[m')
            else:
                gr = Funcoes.voltasgraus(testsegur)
                print(f'Não deu uma volta completa  , e parou em {gr}º graus ')
                print(f'{gr} na forma positiva')
                Funcoes.cor()
                print('Está no sentido anti-horario')
                qua = gr
                Funcoes.cor()
                Funcoes.qp(qua)
                Funcoes.cor()
                print(f'A expressão é \033[34mX = {qua} + K . 360\033[m ou Em radiano é \033[34mX = {Funcoes.graurad(gr)} + K * 2pi\033[m')
                Funcoes.cor()

    loop=input('\033[36mDeseja calcular novamente ? S/N\033[m\n').upper()
    while(loop != 'S' and loop != 'N'):
        print('\033[31mERRO resposta invalida :(\033[m')
        loop = input('\033[36mDeseja calcular novamente ? S/N\033[m\n').upper()

